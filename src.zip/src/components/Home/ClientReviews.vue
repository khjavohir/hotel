<template>
  <section class="py-16 m-auto w-[90%] overflow-hidden">
    <div class="container mx-auto px-4">
      <h2 class="text-3xl md:text-4xl font-bold text-center text-blue-950 mb-4">
        Что говорят наши гости
      </h2>
      <p class="text-gray-600 text-center mb-12 max-w-2xl mx-auto">
        Реальные истории от тех, кто уже жил у нас
      </p>


    </div>
  </section>
</template>
